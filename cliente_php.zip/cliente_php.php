<?php

$cliente = new SoapClient('');
$resultado= $cliente->Procesar_Pagos([
    "total" =>1000,
    "pago"=>100
])->return;
if($resultado>=0){
    echo 'Pago realizado';
}else{
    echo 'dinero insuficiente';
}
